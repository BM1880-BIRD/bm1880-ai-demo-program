Relu, Conv, ConvRelu, ConvTranspose, AveragePool, AveragePoolRelu, MaxPool,
    MaxPoolRelu, Sum, SumRelu, Send, Receive, BatchNormalization, FC,
    GivenTensorFill, Concat, Softmax, ChannelShuffle, Add, Reshape, Flatten,
    NCHW2NHWC, NHWC2NCHW
