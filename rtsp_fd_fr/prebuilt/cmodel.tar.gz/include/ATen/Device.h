#pragma once
#include <ATen/core/Device.h>
