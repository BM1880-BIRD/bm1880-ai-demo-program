#pragma once
#include <ATen/core/ATenGeneral.h> // for BC reasons
#include <ATen/core/Backend.h>
#include <ATen/core/ScalarType.h>
