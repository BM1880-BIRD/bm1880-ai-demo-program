#pragma once

#include "ATen/core/Macros.h"

// TODO: Merge the *_API macros.
#define AT_API AT_CORE_API
