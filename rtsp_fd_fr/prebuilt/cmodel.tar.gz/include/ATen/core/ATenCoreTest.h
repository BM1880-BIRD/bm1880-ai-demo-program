#pragma once

#include <ATen/core/Macros.h>

namespace at {

AT_CORE_API int CoreTest();
}
